# Mumble2
A real time messaging & video calling. Youtube tutorial will be upload in the comming days.

Live Demo: https://www.mumble2.dev/

# Installation
* 1 - clone repo https://github.com/divanov11/mumble2
* 2 - Create an account on agora.io and create an app to generate an APP ID
* 3 - Update APP ID, Temp Token and Channel Name in room_rtc.js
```javascript
let APP_ID = "YOU-APP-ID"
```


<img src="./images/preview.png">  
